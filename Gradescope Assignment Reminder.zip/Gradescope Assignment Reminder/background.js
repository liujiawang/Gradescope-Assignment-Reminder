chrome.runtime.onInstalled.addListener(() => {
    console.log('Extension Successfully Installed');
})
/*
chrome.bookmarks.onCreated.addListener(() => {
    alert('Bookmark saved');
})
*/




